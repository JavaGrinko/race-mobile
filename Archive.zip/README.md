# Установка и запуск

```sh
git clone https://github.com/JavaGrinko/race-mobile.git
cd race-mobile
npm i
npm start
```

# Шпаргалка по гит
## Сохранить изменения
```sh
git add .
git commit -m "что сделано"
git push origin master
```


Шина по сухому асфальту
0,50-0,70
Шина по мокрому асфальту
0,35—0,45
Шина по сухой грунтовой дороге
0,40—0,50
Шина по мокрой грунтовой дороге
0,30-0,40
Шина по гладкому льду
0,15—0,20
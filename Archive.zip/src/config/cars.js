export const CARS = {
    DEMO_CAR: {
        imageSrc: "images/car-test.png",
        width: 53,
        height: 100,
        maxSpeed: 10,
        acceleration: 0.1
    },
    BUGATTI: {
        imageSrc: "images/bugatti.png",
        width: 53,
        height: 100,
        maxSpeed: 3,
        acceleration: 2
    }
}
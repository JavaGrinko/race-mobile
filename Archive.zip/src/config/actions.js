export const ACTIONS = {
    startRace: (object, event) => {
        console.log('сработал action');
    }
}
export const EventType = {
    COLLISION: 'COLLISION',
    FINISH_RACE: 'FINISH_RACE'
}
export default class HeadCrab {
    constructor(car) {
        this.car = car;
    }

    renderTargetLine(canvas, nextPoint) {
        canvas.beginPath();
        canvas.moveTo(this.car.x, this.car.y);
        canvas.lineTo(nextPoint.x, nextPoint.y);
        canvas.stroke();
    }

    control(canvas) {
        const { car } = this;
        let nextPoint = this.getNextPoint();
        this.renderTargetLine(canvas, nextPoint);
        let a = car.y - nextPoint.y;
        let c = car.x - nextPoint.x;
        let b = Math.sqrt(a * a + c * c);
        let sinA = a * Math.sin(Math.PI / 2) / b;
        let alpha;
        if (nextPoint.y > car.y) {
            alpha = 90 + Math.asin(sinA) * 57.2958;
        } else {
            alpha = 90 - Math.asin(sinA) * 57.2958;
        }
        if (nextPoint.x < car.x) {
            alpha = 180 - alpha;
        }
        car.angle = alpha;
        // console.log(nextPoint);
        // let ab = this.car.angleBetween(nextPoint);
        // console.log('угол бота ' + this.car.angle + ', угол до чекпоинта ' + ab);
        car.increaseSpeed();
    }

    getNextPoint(){
        const { lapCounter } = this.car;
        console.log(lapCounter.currentCheckpoint);
        if (lapCounter.currentCheckpoint === -1 && lapCounter.times.length === 0) {
            let start = this.getStartLine();
            let center = start.getCenterPoint(); 
            return center;
        } else {
            let checkpoint = this.getCheckpoint(lapCounter.currentCheckpoint + 1);
            let center = checkpoint.getCenterPoint();
            return center;
        }
    }

    getStartLine() {
        const { walls } = this.car.world;
        return walls.filter(w => w.name === "start_line")[0];
    }

    getCheckpoint(num) {
        const { walls } = this.car.world;
        return walls.filter(w => w.name === `checkpoint_${num}`)[0];
    }
}